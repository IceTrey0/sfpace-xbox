# Fancy Custom Level Collection – Xbox Dev Mode (Ruffle + UWP)

## Setup (all doable from a phone browser)
1. Create a GitHub repo and upload these files (GitHub web: Add file → Upload files, or use github.dev).
2. Make a Release tagged `game-assets` and attach `sfpa-ce.zip` (the original game zip).
3. Actions tab → "Build Xbox package" → Run workflow.
4. When finished, download the `xbox-package` artifact (zip).
5. Xbox Dev Mode → Device Portal (`https://<xbox-ip>:11443`) → Add → pick the .appx,
   add the dependency .appx files from the `Dependencies` list, then Go. (Upload the .cer if asked.)

In-app: the green log shows boot/load errors. Press Menu/Start to hide/show it.
